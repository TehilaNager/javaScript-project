import { products } from "./products.js";

const cards = document.getElementById("cards");
const searchInput = document.getElementById("searchInput");
const logo = document.querySelector(".logo")
const navbarMenu = document.getElementById('navbarMenu');
const bsCollapse = new bootstrap.Collapse(navbarMenu, { toggle: false });
const cartCount = document.querySelector(".cart-count");
const cartWrapper = document.querySelector(".cart-wrapper");

const cartItems = {};
let countItems = 0;
let currentCategory = "ירקות";

const savedCart = localStorage.getItem("cartItems");
const savedCount = localStorage.getItem("countItems");

if (savedCart) {
    Object.assign(cartItems, JSON.parse(savedCart));
};

if (savedCount) {
    countItems = parseInt(savedCount);
};

cartCount.innerHTML = countItems;

function getItemCount(item) {
    return item.type === "unit" ? item.quantity : 1;
}

function updateCountItems() {
    countItems = Object.values(cartItems).reduce((acc, item) => acc + getItemCount(item), 0);
    cartCount.innerHTML = countItems;
}

function saveCartToLocalStorage() {
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
    localStorage.setItem("countItems", countItems);
};

searchInput.addEventListener("input", () => {
    const searchTerm = searchInput.value.trim().toLowerCase();

    if (searchTerm === "") {
        showCards(productsFiltered("ירקות"), "ירקות");
        return;
    };

    const filtered = products.filter(product =>
        product.name.toLowerCase().includes(searchTerm)
    );

    if (filtered.length === 0) {
        cards.innerHTML = `<p style="font-size: 1.2rem; color: #555; margin-top: 2rem; text-align: center;">
          לא נמצאו תוצאות עבור "${searchTerm}"
        </p>`;
    } else {
        showCards(filtered);
    };
});

logo.addEventListener("click", () => {
    showCards(productsFiltered("ירקות"), "ירקות");
});

function productsFiltered(category) {
    return products.filter(product => product.category === category);
};

function showCards(cardsFiltered, category = null) {
    if (category) currentCategory = category;

    cards.innerHTML = "";
    cardsFiltered.forEach(card => {
        cards.innerHTML += renderProductCard(card);
    });
    attachQuantityHandlers();
    handleAddToCartButtons();
};

function renderProductCard(card) {
    const isInCart = !!cartItems[card.name];
    const quantityInCart = isInCart ? cartItems[card.name].quantity : (card.type === "weight" ? 0.1 : 1);

    return `
    <div class="product-card mb-4 position-relative">
        ${isInCart ? `
        <div class="in-cart-label">נבחר</div>` : ''}
        <img src=${card.image} alt=${card.name} />
        <div class="product-card-body">
            <h3 class="product-title">${card.name}</h3>
            <div class="product-price">${card.price.toFixed(2)} ₪ ${card.type === "unit" ? "ליחידה" : 'לק"ג'}</div>
            <div class="product-actions">
                <div class="quantity-wrapper">
                    <button type="button" class="quantity-btn minus">−</button>
                    <input
                        type="number"
                        class="product-quantity"
                        min=${card.type === "weight" ? "0.1" : "1"}
                        step=${card.type === "weight" ? "0.1" : "1"}
                        value=${quantityInCart}
                    />
                    <button type="button" class="quantity-btn plus">+</button>
                </div>
                ${isInCart
            ? `
                      <button class="btn-update btn-add">עדכן 🔁</button>
                      <button class="btn-remove-from-card btn btn-danger">הסר 🗑️</button>
                      `
            : `<button class="btn-add">הוספה לעגלה 🛒</button>`
        }            </div>
        </div>
    </div>`;
};

function attachQuantityHandlers() {
    const wrappers = document.querySelectorAll(".quantity-wrapper");

    wrappers.forEach(wrapper => {
        const input = wrapper.querySelector(".product-quantity");
        const step = parseFloat(input.step) || 1;
        const min = parseFloat(input.min) || 0;

        const updateValue = (direction) => {
            let current = parseFloat(input.value) || 0;
            let newValue = current + (direction * step);
            if (newValue < min) newValue = min;
            newValue = Math.round(newValue * 10) / 10;
            input.value = newValue.toFixed(1);
            input.dispatchEvent(new Event("change"));
        };

        wrapper.querySelector(".quantity-btn.plus").addEventListener("click", () => updateValue(1));
        wrapper.querySelector(".quantity-btn.minus").addEventListener("click", () => updateValue(-1));
    });
}

function handleAddToCartButtons() {
    document.querySelectorAll(".btn-add, .btn-update").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const productCard = e.target.closest(".product-card");
            addOrUpdateCart(productCard);
        });
    });

    document.querySelectorAll(".btn-remove, .btn-remove-from-card").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const productCard = e.target.closest(".product-card");
            const name = productCard.querySelector(".product-title").innerText;
            removeFromCart(name);
        });
    });
}

function addOrUpdateCart(productCard) {
    const name = productCard.querySelector(".product-title").innerText;
    const imageSrc = productCard.querySelector("img").src;
    const quantityInput = productCard.querySelector(".product-quantity");
    const quantity = parseFloat(quantityInput.value);
    const priceText = productCard.querySelector(".product-price").innerText;
    const type = priceText.includes("ליחידה") ? "unit" : "weight";
    const priceMatch = priceText.match(/[\d.]+/);
    const unitPrice = priceMatch ? parseFloat(priceMatch[0]) : 0;

    handleAddToCart({ name, imageSrc, quantity, type, unitPrice });
};

function removeFromCart(name, context = "category") {
    if (!cartItems[name]) return;

    Swal.fire({
        title: `האם להסיר את המוצר "${name}" מהעגלה?`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "כן, הסר",
        cancelButtonText: "ביטול",
        reverseButtons: true
    }).then(result => {
        if (result.isConfirmed) {
            delete cartItems[name];
            updateCountItems();
            saveCartToLocalStorage();
            if (context === "cart") {
                showCartPage();
            } else {
                showCards(productsFiltered(currentCategory), currentCategory);  // אם אנחנו בעמוד קטגוריה — להראות את המוצרים בקטגוריה
            }

            Swal.fire({
                icon: "success",
                title: `"${name}" הוסר מהעגלה.`,
                timer: 1500,
                showConfirmButton: false
            });
        }
    });
};

function validateQuantity(quantity, type) {
    const min = type === "weight" ? 0.1 : 1;
    const max = type === "weight" ? 20 : 50;
    if (quantity < min || quantity > max) {
        Swal.fire({
            icon: 'error',
            title: 'כמות לא חוקית',
            text: `אנא הזן כמות בין ${min} ל-${max} ${getQuantityLabel(quantity, type)}.`,
        });
        return false;
    }
    return true;
}

async function handleAddToCart({ name, imageSrc, quantity, type, unitPrice }) {
    if (!validateQuantity(quantity, type)) return;

    const quantityLabel = getQuantityLabel(quantity, type);

    if (cartItems[name]) {
        const result = await Swal.fire({
            title: `המוצר "${name}" כבר קיים בעגלה!`,
            html: `
              <img src="${imageSrc}" alt="${name}" style="width:100px; height:100px; object-fit: contain; margin-bottom: 1rem;" />
              <p>האם תרצה לשנות את הכמות ל-${quantity} ${quantityLabel}?</p>
            `,
            showCancelButton: true,
            confirmButtonText: 'כן, לשנות כמות',
            cancelButtonText: 'לא',
            reverseButtons: true
        });

        if (!result.isConfirmed) return;

        cartItems[name].quantity = quantity;
        updateCountItems();
        saveCartToLocalStorage();
        showCards(productsFiltered(currentCategory), currentCategory);

        Swal.fire({
            icon: 'success',
            title: 'הכמות עודכנה',
            text: `כמות "${name}" עודכנה ל-${quantity.toFixed(2)}.`,
            timer: 2000,
            showConfirmButton: false
        });
    } else {
        cartItems[name] = { quantity, unitPrice, imageSrc, type };
        updateCountItems();
        saveCartToLocalStorage();
        showCards(productsFiltered(currentCategory), currentCategory);
    }

    showToast({ name, imageSrc, quantity: cartItems[name].quantity, unitPrice });
}

function showToast({ name, imageSrc, quantity, unitPrice }) {
    const total = (quantity * unitPrice).toFixed(2);
    document.getElementById("toastImage").src = imageSrc;
    document.getElementById("toastName").innerText = name;

    const toastDetails = document.getElementById("toastDetails");
    toastDetails.innerHTML = "";

    toastDetails.appendChild(Object.assign(document.createElement("div"), {
        innerText: `${quantity.toFixed(2)} × ${unitPrice.toFixed(2)} ₪`
    }));

    toastDetails.appendChild(Object.assign(document.createElement("div"), {
        innerText: `סה"כ: ${total} ₪`,
        className: "fw-bold"
    }));

    const toastEl = document.getElementById("productAddedToast");
    const toast = new bootstrap.Toast(toastEl);
    toast.show();
};

function getQuantityLabel(quantity, type) {
    if (type === "weight") return 'ק"ג';
    return quantity > 1 ? "יחידות" : "יחידה";
};

function showCartPage() {
    let rowsHTML = "";
    let totalPrice = 0;

    for (const name in cartItems) {
        const { quantity, unitPrice, imageSrc, type } = cartItems[name];
        const itemTotal = (quantity * unitPrice).toFixed(2);
        totalPrice += parseFloat(itemTotal);

        const step = type === "weight" ? 0.1 : 1;
        const min = step;

        rowsHTML += `
        <tr>
          <td class="text-center d-flex align-items-center justify-content-start gap-1">
            <img src="${imageSrc}" alt="${name}" class="product-img-table" />
            <span class="fw-bold">${name}</span>
          </td>
          <td>₪${unitPrice.toFixed(2)}</td>
          <td>
            <input
              type="number"
              class="form-control quantity-input mx-auto"
              style="font-size: 0.8rem"
              min="${min}"
              step="${step}"
              value="${quantity}"
              data-name="${name}"
            />
          </td>
          <td>₪${itemTotal}</td>
          <td class="p-0 align-middle">
            <div class="d-flex justify-content-center">
              <button class="btn btn-danger btn-sm fw-bold btn-remove" data-name="${name}">הסר</button>
            </div>
          </td>
        </tr>`;
    }

    cards.innerHTML = `
      <div class="d-flex flex-column w-100 align-items-center px-2">
        <h2 class="text-center mb-4 fw-bold">🛒 עגלת הקניות שלי</h2>
        <div class="table-responsive" style="max-width: 1000px; width: 100%;">
          <table class="table align-middle text-center shadow cart-table w-100">
            <thead>
              <tr>
                <th style="width: 25%;">מוצר</th>
                <th style="width: 20%;">מחיר</th>
                <th style="width: 20%;">כמות</th>
                <th style="width: 20%;">סה"כ</th>
                <th style="width: 15%;"></th>
              </tr>
            </thead>
            <tbody>
              ${rowsHTML || '<tr><td colspan="5" class="text-center py-4">העגלה ריקה</td></tr>'}
            </tbody>
            <tfoot>
              <tr class="table-warning fw-bold">
                <td colspan="4">
                    <p class="text-center m-0">סה"כ לתשלום: <span class="text-danger">₪${totalPrice.toFixed(2)}</span></p>
                    <p class="text-center m-0">סה"כ מוצרים: <span class="text-danger">${countItems}</span></p>
                </td>
                <td colspan="2" class="text-center"> 
                    <button class="btn btn-secondary btn-sm fw-bold" id="clearCartBtn">אפס עגלה</button>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    `;

    attachCartEvents();

    document.getElementById("clearCartBtn")?.addEventListener("click", () => {
        if (Object.keys(cartItems).length === 0) {
            Swal.fire({
                icon: 'info',
                title: 'העגלה ריקה',
                text: 'אין מוצרים בעגלה לאיפוס.',
                confirmButtonText: 'אישור',
                confirmButtonColor: '#3085d6',
            })
        } else {
            Swal.fire({
                title: "האם אתה בטוח?",
                text: "הפעולה תמחק את כל המוצרים מהעגלה.",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "כן, רוקן עגלה",
                cancelButtonText: "ביטול"
            }).then((result) => {
                if (result.isConfirmed) {
                    for (const key in cartItems) delete cartItems[key];
                    countItems = 0;
                    cartCount.innerHTML = countItems;
                    localStorage.removeItem("cartItems");
                    localStorage.removeItem("countItems");
                    showCartPage();
                    Swal.fire({
                        icon: "success",
                        title: "העגלה רוקנה בהצלחה!",
                        timer: 1500,
                        showConfirmButton: false
                    });
                }
            });
        }
    });
}

function attachCartEvents() {
    const quantityInput = document.querySelectorAll(".quantity-input");
    const btnRemove = document.querySelectorAll(".btn-remove");

    quantityInput.forEach(input => {
        input.addEventListener("change", () => {
            const name = input.dataset.name;
            const type = cartItems[name].type;
            let rawValue = parseFloat(input.value);

            const isWeight = type === "weight";

            if (isNaN(rawValue) || rawValue <= 0) {
                Swal.fire({
                    icon: "error",
                    title: "כמות לא חוקית",
                    text: "יש להזין כמות גדולה מ-0 או ללחוץ על 'הסר'",
                });
                input.value = cartItems[name].quantity.toFixed(isWeight ? 2 : 0);
                return;
            }

            const newQuantity = parseFloat(rawValue.toFixed(isWeight ? 2 : 0));
            cartItems[name].quantity = newQuantity;
            saveCartToLocalStorage();
            updateCountItems();
            showCartPage();
        });
    });

    btnRemove.forEach(button => {
        button.addEventListener("click", () => {
            const name = button.dataset.name;
            removeFromCart(name, "cart");
        });
    });
};

cartWrapper.addEventListener("click", () => {
    showCartPage();
});

showCards(productsFiltered("ירקות"), "ירקות");

const categoryButtons = [
    { id: "vegetables", category: "ירקות" },
    { id: "fruits", category: "פירות" },
    { id: "pastries", category: "מאפים" },
    { id: "dairyProducts", category: "מוצרי חלב" },
    { id: "drinking", category: "שתייה" },
    { id: "cleaningMaterials", category: "חומרי ניקוי" },
    { id: "dryCarbohydrates", category: "פחמימות יבשות" },
    { id: "cannedFood", category: "שימורים" },
    { id: "sauces", category: "רטבים וממרחים" },
    { id: "cookingMaterials", category: "תבלינים וחומרי בישול" },
    { id: "sweets", category: "חטיפים ומתוקים" },
    { id: "frozen", category: "מוצרים קפואים" },
    { id: "cleaningMaterials-sm", category: "חומרי ניקוי" },
    { id: "dryCarbohydrates-sm", category: "פחמימות יבשות" },
    { id: "cannedFood-sm", category: "שימורים" },
    { id: "sauces-sm", category: "רטבים וממרחים" },
    { id: "cookingMaterials-sm", category: "תבלינים וחומרי בישול" },
    { id: "sweets-sm", category: "חטיפים ומתוקים" },
    { id: "frozen-sm", category: "מוצרים קפואים" },
];

categoryButtons.forEach(({ id, category }) => {
    const btn = document.getElementById(id);
    if (btn) {
        btn.addEventListener("click", () => {
            showCards(productsFiltered(category), category);

            if (window.innerWidth < 768) {
                bsCollapse.hide();
            }
        });
    }
});