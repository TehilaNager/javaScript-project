import { products } from "./products.js";

const cards = document.getElementById("cards");
const searchInput = document.getElementById("searchInput");
const logo = document.querySelector(".logo")
const navbarMenu = document.getElementById('navbarMenu');
const bsCollapse = new bootstrap.Collapse(navbarMenu, { toggle: false });
const cartCount = document.querySelector(".cart-count");
const cartWrapper = document.querySelector(".cart-wrapper");

const cartItems = {};
let countItems = 0;
let currentCategory = "ירקות";

const savedCart = localStorage.getItem("cartItems");
const savedCount = localStorage.getItem("countItems");

if (savedCart) {
    Object.assign(cartItems, JSON.parse(savedCart));
};

if (savedCount) {
    countItems = parseInt(savedCount);
};

cartCount.innerHTML = countItems;

function getItemCount(item) {
    return item.type === "unit" ? item.quantity : 1;
}

function updateCountItems() {
    countItems = Object.values(cartItems).reduce((acc, item) => acc + getItemCount(item), 0);
    cartCount.innerHTML = countItems;
}

function saveCartToLocalStorage() {
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
    localStorage.setItem("countItems", countItems);
};

searchInput.addEventListener("input", () => {
    categoryButtons.forEach(({ id }) => {
        const button = document.getElementById(id);
        if (button) button.classList.remove("active-category");
    });

    const searchTerm = searchInput.value.trim().toLowerCase();

    if (searchTerm === "") {
        showCards(productsFiltered("ירקות"), "ירקות");
        const defaultBtn = document.getElementById("vegetables");
        if (defaultBtn) defaultBtn.classList.add("active-category");
        return;
    };

    const filtered = products.filter(product =>
        product.name.toLowerCase().includes(searchTerm)
    );

    if (filtered.length === 0) {
        cards.innerHTML = `<p style="font-size: 1.2rem; color: #555; margin-top: 2rem; text-align: center;">
          לא נמצאו תוצאות עבור "${searchTerm}"
        </p>`;
    } else {
        showCards(filtered);
    };
});

logo.addEventListener("click", () => {
    showCards(productsFiltered("ירקות"), "ירקות");
    document.getElementById("vegetables")?.classList.add("active-category");
});

function productsFiltered(category) {
    return products.filter(product => product.category === category);
};

function showCards(cardsFiltered, category = null) {
    if (category) currentCategory = category;

    cards.innerHTML = "";
    cardsFiltered.forEach(card => {
        cards.innerHTML += renderProductCard(card);
    });
    attachQuantityHandlers();
    handleAddToCartButtons();
};

function renderProductCard(card) {
    const isInCart = !!cartItems[card.name];
    const quantityInCart = isInCart ? cartItems[card.name].quantity : (card.type === "weight" ? 0.1 : 1);

    return `
    <div class="product-card mb-4 position-relative">
        ${isInCart ? `
        <div class="in-cart-label">נבחר</div>` : ''}
        <img src=${card.image} alt=${card.name} />
        <div class="product-card-body">
            <h3 class="product-title">${card.name}</h3>
            <div class="product-price">${card.price.toFixed(2)} ₪ ${card.type === "unit" ? "ליחידה" : 'לק"ג'}</div>
            <div class="product-actions">
                <div class="quantity-wrapper">
                    <button type="button" class="quantity-btn minus">−</button>
                    <input
                        type="number"
                        class="product-quantity"
                        min=${card.type === "weight" ? "0.1" : "1"}
                        step=${card.type === "weight" ? "0.1" : "1"}
                        value=${quantityInCart}
                    />
                    <button type="button" class="quantity-btn plus">+</button>
                </div>
                ${isInCart
            ? `
                      <button class="btn-update btn-add">עדכן 🔁</button>
                      <button class="btn-remove-from-card btn btn-danger">הסר 🗑️</button>
                      `
            : `<button class="btn-add">הוספה לעגלה 🛒</button>`
        }            </div>
        </div>
    </div>`;
};

function attachQuantityHandlers() {
    const wrappers = document.querySelectorAll(".quantity-wrapper");

    wrappers.forEach(wrapper => {
        const input = wrapper.querySelector(".product-quantity");
        const step = parseFloat(input.step) || 1;
        const min = parseFloat(input.min) || 0;

        const updateValue = (direction) => {
            let current = parseFloat(input.value) || 0;
            let newValue = current + (direction * step);
            if (newValue < min) newValue = min;
            newValue = Math.round(newValue * 10) / 10;
            input.value = newValue.toFixed(1);
            input.dispatchEvent(new Event("change"));
        };

        wrapper.querySelector(".quantity-btn.plus").addEventListener("click", () => updateValue(1));
        wrapper.querySelector(".quantity-btn.minus").addEventListener("click", () => updateValue(-1));
    });
}

function handleAddToCartButtons() {
    document.querySelectorAll(".btn-add, .btn-update").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const productCard = e.target.closest(".product-card");
            addOrUpdateCart(productCard);
        });
    });

    document.querySelectorAll(".btn-remove, .btn-remove-from-card").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const productCard = e.target.closest(".product-card");
            const name = productCard.querySelector(".product-title").innerText;
            removeFromCart(name);
        });
    });
}

function addOrUpdateCart(productCard) {
    const name = productCard.querySelector(".product-title").innerText;
    const imageSrc = productCard.querySelector("img").src;
    const quantityInput = productCard.querySelector(".product-quantity");
    const quantity = parseFloat(quantityInput.value);
    const priceText = productCard.querySelector(".product-price").innerText;
    const type = priceText.includes("ליחידה") ? "unit" : "weight";
    const priceMatch = priceText.match(/[\d.]+/);
    const unitPrice = priceMatch ? parseFloat(priceMatch[0]) : 0;

    handleAddToCart({ name, imageSrc, quantity, type, unitPrice });
};

function removeFromCart(name, context = "category") {
    if (!cartItems[name]) return;

    Swal.fire({
        title: `האם להסיר את המוצר "${name}" מהעגלה?`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "כן, הסר",
        cancelButtonText: "ביטול",
        reverseButtons: true
    }).then(result => {
        if (result.isConfirmed) {
            delete cartItems[name];
            updateCountItems();
            saveCartToLocalStorage();
            if (context === "cart") {
                showCartPage();
            } else {
                showCards(productsFiltered(currentCategory), currentCategory);
            }

            Swal.fire({
                icon: "success",
                title: `"${name}" הוסר מהעגלה.`,
                timer: 1500,
                showConfirmButton: false
            });
        }
    });
};

function validateQuantity(quantity, type) {
    const min = type === "weight" ? 0.1 : 1;
    const max = type === "weight" ? 20 : 50;
    if (quantity < min || quantity > max) {
        Swal.fire({
            icon: 'error',
            title: 'כמות לא חוקית',
            text: `אנא הזן כמות בין ${min} ל-${max} ${getQuantityLabel(quantity, type)}.`,
        });
        return false;
    }
    return true;
}

async function handleAddToCart({ name, imageSrc, quantity, type, unitPrice }) {
    if (!validateQuantity(quantity, type)) return;

    const quantityLabel = getQuantityLabel(quantity, type);

    if (cartItems[name]) {
        const result = await Swal.fire({
            title: `המוצר "${name}" כבר קיים בעגלה!`,
            html: `
              <img src="${imageSrc}" alt="${name}" style="width:100px; height:100px; object-fit: contain; margin-bottom: 1rem;" />
              <p>האם תרצה לשנות את הכמות ל-${quantity} ${quantityLabel}?</p>
            `,
            showCancelButton: true,
            confirmButtonText: 'כן, לשנות כמות',
            cancelButtonText: 'לא',
            reverseButtons: true
        });

        if (!result.isConfirmed) return;

        cartItems[name].quantity = quantity;
        updateCountItems();
        saveCartToLocalStorage();
        showCards(productsFiltered(currentCategory), currentCategory);

        Swal.fire({
            icon: 'success',
            title: 'הכמות עודכנה',
            text: `כמות "${name}" עודכנה ל-${quantity.toFixed(2)}.`,
            timer: 2000,
            showConfirmButton: false
        });
    } else {
        cartItems[name] = { quantity, unitPrice, imageSrc, type };
        updateCountItems();
        saveCartToLocalStorage();
        showCards(productsFiltered(currentCategory), currentCategory);
    }

    showToast({ name, imageSrc, quantity: cartItems[name].quantity, unitPrice });
}

function showToast({ name, imageSrc, quantity, unitPrice }) {
    const total = (quantity * unitPrice).toFixed(2);
    document.getElementById("toastImage").src = imageSrc;
    document.getElementById("toastName").innerText = name;

    const toastDetails = document.getElementById("toastDetails");
    toastDetails.innerHTML = "";

    toastDetails.appendChild(Object.assign(document.createElement("div"), {
        innerText: `${quantity.toFixed(2)} × ${unitPrice.toFixed(2)} ₪`
    }));

    toastDetails.appendChild(Object.assign(document.createElement("div"), {
        innerText: `סה"כ: ${total} ₪`,
        className: "fw-bold"
    }));

    const toastEl = document.getElementById("productAddedToast");
    const toast = new bootstrap.Toast(toastEl);
    toast.show();
};

function getQuantityLabel(quantity, type) {
    if (type === "weight") return 'ק"ג';
    return quantity > 1 ? "יחידות" : "יחידה";
};

function showCartPage() {
    let rowsHTML = "";
    let totalPrice = 0;

    for (const name in cartItems) {
        const { quantity, unitPrice, imageSrc, type } = cartItems[name];
        const itemTotal = (quantity * unitPrice).toFixed(2);
        totalPrice += parseFloat(itemTotal);

        const step = type === "weight" ? 0.1 : 1;
        const min = step;

        rowsHTML += `
        <tr>
          <td class="text-center d-flex align-items-center justify-content-start gap-1">
            <img src="${imageSrc}" alt="${name}" class="product-img-table" />
            <span class="fw-bold">${name}</span>
          </td>
          <td>₪${unitPrice.toFixed(2)}</td>
          <td>
            <input
              type="number"
              class="form-control quantity-input mx-auto"
              style="font-size: 0.8rem"
              min="${min}"
              step="${step}"
              value="${quantity}"
              data-name="${name}"
            />
          </td>
          <td>₪${itemTotal}</td>
          <td class="p-0 align-middle">
            <div class="d-flex justify-content-center">
              <button class="btn btn-danger btn-sm fw-bold btn-remove" data-name="${name}">הסר</button>
            </div>
          </td>
        </tr>`;
    }

    cards.innerHTML = `
      <div class="d-flex flex-column w-100 align-items-center px-2">
        <h2 class="text-center mb-4 fw-bold">🛒 עגלת הקניות שלי</h2>
        <div class="table-responsive" style="max-width: 1000px; width: 100%;">
          <table class="table align-middle text-center shadow cart-table w-100">
            <thead>
              <tr>
                <th style="width: 25%;">מוצר</th>
                <th style="width: 20%;">מחיר</th>
                <th style="width: 20%;">כמות</th>
                <th style="width: 20%;">סה"כ</th>
                <th style="width: 15%;"></th>
              </tr>
            </thead>
            <tbody>
              ${rowsHTML || '<tr><td colspan="5" class="text-center py-4">העגלה ריקה</td></tr>'}
            </tbody>
            <tfoot>
              <tr class="table-warning fw-bold">
                <td colspan="4">
                    <p class="text-center m-0">סה"כ לתשלום: <span class="text-danger">₪${totalPrice.toFixed(2)}</span></p>
                    <p class="text-center m-0">סה"כ מוצרים: <span class="text-danger">${countItems}</span></p>
                </td>
                <td colspan="2" class="text-center"> 
                    <button class="btn btn-secondary btn-sm fw-bold" id="clearCartBtn">אפס עגלה</button>
                </td>
              </tr>
            </tfoot>
          </table>
            <div class="d-flex justify-content-center my-3">
                <button class="pay">לתשלום</button>
            </div>
        </div>
      </div>
    `;

    btnPay();

    categoryButtons.forEach(({ id }) => {
        const button = document.getElementById(id);
        if (button) button.classList.remove("active-category");
    });

    attachCartEvents();

    document.getElementById("clearCartBtn")?.addEventListener("click", () => {
        if (Object.keys(cartItems).length === 0) {
            Swal.fire({
                icon: 'info',
                title: 'העגלה ריקה',
                text: 'אין מוצרים בעגלה לאיפוס.',
                confirmButtonText: 'אישור',
                confirmButtonColor: '#3085d6',
            })
        } else {
            Swal.fire({
                title: "האם אתה בטוח?",
                text: "הפעולה תמחק את כל המוצרים מהעגלה.",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "כן, רוקן עגלה",
                cancelButtonText: "ביטול"
            }).then((result) => {
                if (result.isConfirmed) {
                    for (const key in cartItems) delete cartItems[key];
                    countItems = 0;
                    cartCount.innerHTML = countItems;
                    localStorage.removeItem("cartItems");
                    localStorage.removeItem("countItems");
                    showCartPage();
                    Swal.fire({
                        icon: "success",
                        title: "העגלה רוקנה בהצלחה!",
                        timer: 1500,
                        showConfirmButton: false
                    });
                }
            });
        }
    });
}

function attachCartEvents() {
    const quantityInput = document.querySelectorAll(".quantity-input");
    const btnRemove = document.querySelectorAll(".btn-remove");

    quantityInput.forEach(input => {
        input.addEventListener("change", () => {
            const name = input.dataset.name;
            const type = cartItems[name].type;
            let rawValue = parseFloat(input.value);

            const isWeight = type === "weight";

            if (isNaN(rawValue) || rawValue <= 0) {
                Swal.fire({
                    icon: "error",
                    title: "כמות לא חוקית",
                    text: "יש להזין כמות גדולה מ-0 או ללחוץ על 'הסר'",
                });
                input.value = cartItems[name].quantity.toFixed(isWeight ? 2 : 0);
                return;
            }

            const newQuantity = parseFloat(rawValue.toFixed(isWeight ? 2 : 0));
            cartItems[name].quantity = newQuantity;
            saveCartToLocalStorage();
            updateCountItems();
            showCartPage();
        });
    });

    btnRemove.forEach(button => {
        button.addEventListener("click", () => {
            const name = button.dataset.name;
            removeFromCart(name, "cart");
        });
    });
};

cartWrapper.addEventListener("click", () => {
    showCartPage();
});


function btnPay() {
    document.querySelector(".pay").addEventListener("click", () => {

        if (Object.keys(cartItems).length <= 0) {
            Swal.fire({
                icon: 'warning',
                title: 'העגלה שלך ריקה',
                html: `
              <p>לא ניתן לבצע תשלום כאשר העגלה ריקה.</p>
              <p>אנא הוסף מוצרים לעגלה לפני שתמשיך לתשלום.</p>
            `,
                confirmButtonText: 'הבנתי',
                confirmButtonColor: '#3085d6'
            });
            return;
        }

        Swal.fire({
            title: 'בחירת אמצעי תשלום',
            html: `
              <p>אנא בחר את אמצעי התשלום שלך:</p>
              <p><strong>שים לב:</strong> תשלום <u>במזומן</u> זמין <strong>רק באיסוף עצמי מהסניף</strong>.</p>
              <p>אם ברצונך להזמין <strong>משלוח</strong> – יש לשלם <u>באשראי</u>.</p>
              <p>ניתן גם לשלם באשראי <u>ולבצע איסוף עצמי</u> לפי בחירתך.</p>
            `,
            showCancelButton: true,
            showDenyButton: true,
            confirmButtonText: 'תשלום באשראי',
            denyButtonText: 'תשלום במזומן (איסוף עצמי)',
            cancelButtonText: 'ביטול',
            icon: 'question'
        }).then((result) => {
            if (result.isConfirmed) {
                handleCreditPayment();
            } else if (result.isDenied) {
                handleCashPayment();
            }
        });

    });
};

function handleCreditPayment() {
    let total = 0;
    for (const item of Object.values(cartItems)) {
        total += item.quantity * item.unitPrice;
    }

    const shippingCost = 15;
    let isDelivery = false;

    Swal.fire({
        title: 'תשלום באשראי',
        html: `
        <form id="creditForm" style="direction: rtl; text-align: center;">
            <p style="color:red;"><strong>סכום ביניים לתשלום:</strong> ₪<span id="baseTotal">${total.toFixed(2)}</span></p>

            <label style="display:block; margin-bottom:5px;">בחר את אופן קבלת ההזמנה:</label>
            <div class="pt-2 pb-3 d-flex justify-content-center" style="gap:15px; flex-direction: column;">
                <div>
                    <input type="radio" name="deliveryType" value="pickup" checked> איסוף עצמי
                </div>
                <div>
                    <input type="radio" name="deliveryType" value="delivery"> משלוח (₪${shippingCost})
                </div>
            </div>

            <p id="finalSummary" style="font-weight: bold; color: #0d6efd; font-size: 1.1em;">
                סה״כ לתשלום: ₪<span id="finalTotal">${total.toFixed(2)}</span>
            </p>

            <div id="deliveryFields" style="display:none;">
                ${customInput("fullName", "שם מלא")}
                ${customInput("address", "כתובת מלאה")}
                ${customInput("phone", "טלפון (נייד או ביתי)")}
            </div>

            ${customInput("cardNumber", "מספר כרטיס אשראי")}

            <div style="display: flex; justify-content: center; align-items: center; gap: 10px; margin: 10px auto; width: 95%;">
                <input type="text" id="expMonth" placeholder="חודש" maxlength="2"
                    style="${inputStyle()} width: 45%; text-align: center;" autocomplete="off">
                <span>/</span>
                <input type="text" id="expYear" placeholder="שנה" maxlength="2"
                    style="${inputStyle()} width: 45%; text-align: center;" autocomplete="off">
            </div>

            ${customInput("cvv", "קוד אימות (CVV)")}
            ${customInput("idNumber", "מספר ת.ז.")}
        </form>`,
        showCancelButton: true,
        confirmButtonText: 'שלח תשלום',
        cancelButtonText: 'ביטול',
        didOpen: () => {
            const deliveryRadios = document.querySelectorAll('input[name="deliveryType"]');
            deliveryRadios.forEach(radio => {
                radio.addEventListener("change", () => {
                    isDelivery = radio.value === "delivery";
                    document.getElementById("deliveryFields").style.display = isDelivery ? "block" : "none";
                    const finalTotal = isDelivery ? (total + shippingCost).toFixed(2) : total.toFixed(2);
                    document.getElementById("finalTotal").textContent = finalTotal;
                });
            });
        },
        preConfirm: () => {
            const card = document.getElementById("cardNumber").value.trim();
            const month = document.getElementById("expMonth").value.trim();
            const year = document.getElementById("expYear").value.trim();
            const cvv = document.getElementById("cvv").value.trim();
            const id = document.getElementById("idNumber").value.trim();

            if (!/^\d{16}$/.test(card)) {
                Swal.showValidationMessage("מספר כרטיס אשראי חייב להכיל 16 ספרות.");
                return false;
            }

            if (!/^\d{3}$/.test(cvv)) {
                Swal.showValidationMessage("CVV חייב להיות 3 ספרות.");
                return false;
            }

            if (!/^\d{9}$/.test(id)) {
                Swal.showValidationMessage("מספר תעודת זהות חייב להיות 9 ספרות.");
                return false;
            }

            if (!/^\d{2}$/.test(month) || !/^\d{2}$/.test(year)) {
                Swal.showValidationMessage("אנא הזן תוקף חוקי: חודש ושנה - כל אחד בשתי ספרות. לדוגמה: חודש 04 ושנה 27");
                return false;
            }


            const mm = parseInt(month);
            const yy = parseInt(year);
            const now = new Date();
            const currentYear = now.getFullYear() % 100;
            const currentMonth = now.getMonth() + 1;

            if (mm < 1 || mm > 12 || yy < currentYear || (yy === currentYear && mm < currentMonth)) {
                Swal.showValidationMessage("תוקף הכרטיס אינו תקף.");
                return false;
            }

            if (isDelivery) {
                const name = document.getElementById("fullName").value.trim();
                const address = document.getElementById("address").value.trim();
                const phone = document.getElementById("phone").value.trim();

                if (name.length < 2 || !/^[\u0590-\u05FFa-zA-Z\s]+$/.test(name)) {
                    Swal.showValidationMessage("אנא הזן שם מלא תקין בעברית או באנגלית.");
                    return false;
                }

                if (address.length < 5) {
                    Swal.showValidationMessage("אנא הזן כתובת מלאה תקינה (לפחות 5 תווים).");
                    return false;
                }

                if (!/^05\d{8}$/.test(phone) && !/^0[2-9]\d{7,8}$/.test(phone)) {
                    Swal.showValidationMessage("אנא הזן מספר טלפון תקין (נייד או ביתי).");
                    return false;
                }
            }

            return true;
        }
    }).then(result => {
        if (result.isConfirmed) {
            Swal.fire({
                icon: 'success',
                title: 'התשלום התקבל בהצלחה!',
                text: isDelivery
                    ? 'ההזמנה נשלחה ותגיע אליך בהקדם :)'
                    : 'ההזמנה נשלחה לסניף, נשמח לראותך באיסוף!',
                confirmButtonText: 'סיום'
            });

            for (const key in cartItems) delete cartItems[key];
            countItems = 0;
            cartCount.innerHTML = countItems;
            localStorage.removeItem("cartItems");
            localStorage.removeItem("countItems");
            showCards(productsFiltered("ירקות"), "ירקות");
        }
    });
}

function customInput(id, placeholder) {
    return `
    <input type="text" id="${id}" placeholder="${placeholder}" autocomplete="off"
        style="${inputStyle()} width: 95%; text-align: right;">
    `;
}

function inputStyle() {
    return `
        direction: rtl;
        display: block;
        margin: 10px auto;
        padding: 12px 16px;
        font-size: 16px;
        border-radius: 12px;
        border: 1px solid #ccc;
        box-sizing: border-box;
        transition: border 0.3s ease;
        outline: none;
    `;
}

function handleCashPayment() {
    let total = 0;

    for (const item of Object.values(cartItems)) {
        total += item.quantity * item.unitPrice;
    }

    const totalFormatted = total.toFixed(2);

    Swal.fire({
        icon: 'info',
        title: 'הזמנה באיסוף עצמי',
        html: `
            <p style="color: red;"><strong>סכום לתשלום:</strong> ₪${totalFormatted}</p>
            <p>התשלום יתבצע בעת איסוף ההזמנה מהסניף.</p>
            <p><strong>יש להגיע לאיסוף תוך 3 ימי עסקים.</strong></p>
            <p style="line-height:1.5"><strong>כתובת הסניף:</strong><br> רחוב הדוגמה 123, תל אביב.</p>
            <p style="line-height:1.5"><strong>שעות פעילות:</strong><br>ימים א׳–ה׳: 07:00–19:00<br>ימי שישי וערבי חג: 06:00-14:00</p>
            <p style="line-height:1.5"><strong>שירות לקוחות:</strong><br><a href="tel:03-1234567">03-1234567</a></p>
            <p style="font-size: 0.9rem; color: #666;">* שים לב: הזמנה שלא תיאסף תוך הזמן הנקוב תבוטל אוטומטית.</p>
            <p style="font-size: 0.9rem; color: #666;">בעת לחיצה על <u>אישור</u> ההזמנה תישלח לסניף.</p>
        `,
        confirmButtonText: 'אישור',
        cancelButtonText: 'ביטול',
        showCancelButton: true,
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                icon: 'success',
                title: 'ההזמנה נקלטה בהצלחה!',
                text: 'ההזמנה נשלחה לסניף. נשמח לראותך באיסוף :)',
                confirmButtonText: 'סיום'
            });

            for (const key in cartItems) delete cartItems[key];
            countItems = 0;
            cartCount.innerHTML = countItems;
            localStorage.removeItem("cartItems");
            localStorage.removeItem("countItems");
            showCards(productsFiltered("ירקות"), "ירקות");
        } else if (result.isDismissed) {
            Swal.fire({
                icon: 'info',
                title: 'הפעולה בוטלה',
                text: 'ניתן לחזור לעגלת הקניות ולעדכן את ההזמנה.',
                confirmButtonText: 'הבנתי'
            });
        }
    });
}

showCards(productsFiltered("ירקות"), "ירקות");

const categoryButtons = [
    { id: "vegetables", category: "ירקות" },
    { id: "fruits", category: "פירות" },
    { id: "pastries", category: "מאפים" },
    { id: "dairyProducts", category: "מוצרי חלב" },
    { id: "drinking", category: "שתייה" },
    { id: "cleaningMaterials", category: "חומרי ניקוי" },
    { id: "dryCarbohydrates", category: "פחמימות יבשות" },
    { id: "cannedFood", category: "שימורים" },
    { id: "sauces", category: "רטבים וממרחים" },
    { id: "cookingMaterials", category: "תבלינים וחומרי בישול" },
    { id: "sweets", category: "חטיפים ומתוקים" },
    { id: "frozen", category: "מוצרים קפואים" },
    { id: "cleaningMaterials-sm", category: "חומרי ניקוי" },
    { id: "dryCarbohydrates-sm", category: "פחמימות יבשות" },
    { id: "cannedFood-sm", category: "שימורים" },
    { id: "sauces-sm", category: "רטבים וממרחים" },
    { id: "cookingMaterials-sm", category: "תבלינים וחומרי בישול" },
    { id: "sweets-sm", category: "חטיפים ומתוקים" },
    { id: "frozen-sm", category: "מוצרים קפואים" },
];

categoryButtons.forEach(({ id, category }) => {
    const btn = document.getElementById(id);
    if (btn) {
        btn.addEventListener("click", () => {
            showCards(productsFiltered(category), category);

            categoryButtons.forEach(({ id }) => {
                const button = document.getElementById(id);
                if (button) button.classList.remove("active-category");
            });

            btn.classList.add("active-category");


            if (window.innerWidth < 768) {
                bsCollapse.hide();
            }
        });
    }

    btn.classList.remove("active-category");
});

document.getElementById("vegetables")?.classList.add("active-category");